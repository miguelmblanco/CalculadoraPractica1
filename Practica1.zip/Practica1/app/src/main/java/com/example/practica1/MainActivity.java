
package com.example.practica1;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    TextView texto; // la pantalla

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.linear);
        texto = findViewById(R.id.Texto);
        // listener para los botones de los numeros los signos y ac y c que es lo que tiene la calculadora
        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pulsar(((Button) v).getText().toString());}
        };

        findViewById(R.id.Boton0).setOnClickListener(listener);
        findViewById(R.id.Boton1).setOnClickListener(listener);
        findViewById(R.id.Boton2).setOnClickListener(listener);
        findViewById(R.id.Boton3).setOnClickListener(listener);
        findViewById(R.id.Boton4).setOnClickListener(listener);
        findViewById(R.id.Boton5).setOnClickListener(listener);
        findViewById(R.id.Boton6).setOnClickListener(listener);
        findViewById(R.id.Boton7).setOnClickListener(listener);
        findViewById(R.id.Boton8).setOnClickListener(listener);
        findViewById(R.id.Boton9).setOnClickListener(listener);
        findViewById(R.id.BotonSumar).setOnClickListener(listener);
        findViewById(R.id.BotonRestar).setOnClickListener(listener);
        findViewById(R.id.BotonMultiplicar).setOnClickListener(listener);
        findViewById(R.id.Botonbarra).setOnClickListener(listener);
        findViewById(R.id.BotonPunto).setOnClickListener(listener);
        findViewById(R.id.BotonAC).setOnClickListener(listener);
        findViewById(R.id.BotonC).setOnClickListener(listener);
    }

    // aqui llega el texto del boton que se pulsa
    void pulsar(String boton) {
        String t = texto.getText().toString();
        String ultimo = ultimoNumero(t);

        if (boton.equals("A/C")) {
            // ac borra todo
            texto.setText("0");

        } else if (boton.equals("C")) {
            // el c lo que hace quita el ultimo numero
            if (t.length() <= 1) {
                texto.setText("0");
            } else {
                texto.setText(t.substring(0, t.length() - 1));
            }

        } else if (boton.equals(".")) {
            // solo un punto por numero
            if (ultimo.contains(".")) {
                return;
            }
            if (ultimo.equals("")) {
                t = t + "0";
            }
            texto.setText(t + ".");

        } else if (esOperador(boton.charAt(0))) {
            // si ya habia un simbolo al final lo cambio
            if (esOperador(t.charAt(t.length() - 1))) {
                t = t.substring(0, t.length() - 1);
            }
            texto.setText(t + boton);

        } else {
            // es un numero, no dejo 0005
            if (ultimo.equals("0")) {
                if (boton.equals("0")) {
                    return;
                }
                t = t.substring(0, t.length() - 1); // quito el 0
            }
            texto.setText(t + boton);
        }}
    // saca el numero que se esta escribiendo
    String ultimoNumero(String t) {
        int i = t.length() - 1;
        while (i >= 0 && !esOperador(t.charAt(i))) {
            i--;
        }
        return t.substring(i + 1);
    }
    boolean esOperador(char c) {
        return c == '+' || c == '-' || c == '*' || c == '/';
    }}